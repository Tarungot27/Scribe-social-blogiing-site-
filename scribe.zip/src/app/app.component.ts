import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  people :any[]=[{
    "name": "Samarth",
    "age":28
  },{
    "name": "Bob",
    "age":34
  },{
    "name": "Alice",
    "age":27
  }]
  nam;
  ag;
  
  constructor(){
  }
  add(name,age){
    this.people.push(this.nam);
  }
}
